// All the inputs for the user.
const OPTIONS = {
    "status":{
       "label":"Status of existing checking account",
       "type":"select",
       "values":[
          "No checking account",
          "Negative",
          "0 - 200",
          "Over 200"
       ]
    },
    "history":{
       "label":"Credit history",
       "type":"select",
       "values":[
          "critical account/ other credits existing (not at this bank)",
          "existing credits paid back duly till now",
          "delay in paying off in the past",
          "no credits taken / all credits paid back duly",
          "all credits at this bank paid back duly"
       ]
    },
    "savingsAcc":{
       "label":"Savings account/bonds",
       "type":"select",
       "values":[
          "unknown / no savings account",
          "less than 100",
          "100 to 500",
          "500 to 1000",
          "more than 1000"
       ]
    },
    "employmentSince":{
       "label":"Present employment since",
       "type":"select",
       "values":[
          "Unemployed",
          "less than 1 year",
          "1 to 4 years",
          "4 to 7 years",
          "more than 7 years"
       ]
    },
    "installmentRate":{
       "label":"Installment rate in percentage of disposable income",
       "type":"int",
       "values":[
          1,
          100
       ]
    },
    "personalStatus":{
       "label":"Personal status and sex",
       "type":"select",
       "values":[
          "male (single)",
          "male (divorced/separated)",
          "male (married/widowed)",
          "female (divorced/separated/married)"
       ]
    },
    "otherDebtors":{
       "label":"Other debtors / guarantors",
       "type":"select",
       "values":[
          "none",
          "guarantor",
          "co-Applicant"
       ]
    },
    "residenceSince":{
       "label":"Present residence since",
       "type":"int",
       "values":[
          1,
          50
       ]
    },
    "property":{
       "label":"Property",
       "type":"select",
       "values":[
          "real estate",
          "building society savings agreement/ life insurance",
          "unknown / no property",
          "car or other"
       ]
    },
    "age":{
       "label":"Age in years",
       "type":"int",
       "values":[
          18,
          75
       ]
    },
    "instPlans":{
       "label":"Other installment plans",
       "type":"select",
       "values":[
          "none",
          "bank",
          "stores"
       ]
    },
    "housing":{
       "label":"Housing",
       "type":"select",
       "values":[
          "own",
          "for free",
          "rent"
       ]
    },
    "numCredits":{
       "label":"Number of existing credits at this bank",
       "type":"int",
       "values":[
          1,
          10
       ]
    },
    "job":{
       "label":"Job",
       "type":"select",
       "values":[
          "skilled employee / official",
          "unskilled - resident",
          "management / self-employed / highly qualified employee / officer",
          "unemployed / unskilled - non-resident"
       ]
    },
    "numPeopleLiable":{
       "label":"Number of people being liable to provide maintenance for",
       "type":"int",
       "values":[
          1,
          10
       ]
    },
    "telephone":{
       "label":"Telephone",
       "type":"select",
       "values":[
          "yes, registered under the customers name",
          "none"
       ]
    },
    "foreignWorker":{
       "label":"Foreign worker",
       "type":"select",
       "values":[
          "Yes",
          "No"
       ]
    }
 };

// The spec of the table we send to the server.
const TABLE_SPEC = [
    {
        "Status of existing checking account": "string"
    },
    {
        "Credit history": "string"
    },
    {
        "Savings account/bonds": "string"
    },
    {
        "Present employment since": "string"
    },
    {
        "Installment rate in percentage of disposable income": "int"
    },
    {
        "Personal status and sex": "string"
    },
    {
        "Other debtors / guarantors": "string"
    },
    {
        "Present residence since": "int"
    },
    {
        "Property": "string"
    },
    {
        "Age in years": "int"
    },
    {
        "Other installment plans": "string"
    },
    {
        "Housing": "string"
    },
    {
        "Number of existing credits at this bank": "int"
    },
    {
        "Job": "string"
    },
    {
        "Number of people being liable to provide maintenance for": "int"
    },
    {
        "Telephone": "string"
    },
    {
        "Foreign worker": "string"
    },
    {
        "Duration in months": "int"
    },
    {
        "Purpose": "string"
    },
    {
        "Credit amount": "int"
    },
];