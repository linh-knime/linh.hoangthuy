// Initialize a new Vue application
const app = new Vue({
    el: '#app',
    // The "state" of our app
    data: {
        duration: 1,
        amount: 1000,
        values: Object.keys(OPTIONS).reduce((mem, key) => Object.assign(mem, {[key]: OPTIONS[key].values[0]}), {}),
        options: Object.keys(OPTIONS).map(key => ({...OPTIONS[key], id: key})),
        score: 0.5
    },
    // Called when the app is rendered. We need to call the server initially to get a score for the defaults.
    mounted: function() {
        this.updateScore();
    },
    methods: {
        // Method for sending the current data to the server and receiving a score
        updateScore: function() {
            var xhttp = new XMLHttpRequest();
            const self = this;
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    const res = JSON.parse(this.responseText);
                    console.log("Receiving data...");
                    console.log(res["table-data"]);
                    // Setting the score here updates the UI
                    self.score = res["table-data"][0][res["table-data"][0].length - 4];
                }
            };
            // TODO: Adjust for your server
            xhttp.open("POST", "http://localhost:8080/knime/rest/v4/repository/Demos/Credit%20Scoring/model/CreditScorer:execution", true);
            xhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
            // Authorization for knimeadmin with pw knimeadmin. You can copy this from the header in Postman.
            xhttp.setRequestHeader("Authorization", "Basic a25pbWVhZG1pbjprbmltZWFkbWlu");
            // Set Prefer to receive minimal output
            xhttp.setRequestHeader("Prefer", "edge-compatible");
            // We send the table with spec. Can be omitted, but with it it is safer.
            const data = {
                "table-input": {
                    "table-data": [[...Object.keys(OPTIONS).map(key => this.values[key]), this.duration, "radio/television", this.amount]],
                    "table-spec": TABLE_SPEC
                }
            };
            console.log("Sending data...");
            console.log(data["table-input"]["table-data"]);
            xhttp.send(JSON.stringify(data));
        }
    }
});